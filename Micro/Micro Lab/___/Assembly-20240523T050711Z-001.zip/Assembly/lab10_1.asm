	ORG 	0000H 		; Lab10Srl1.Sub
	JMP 	0100H
	ORG 	0100H
	MOV 	SP,#3FH
	CLR 	EA 		; Disable All
	SETB 	P1.0 		; Input Pin
	JB 	P1.0,$ 		; Wait Press P1.0
	CALL 	Delay 		; Start Delay
	MOV 	TMOD,#00100001B ; T1M2 T0M1
	MOV 	SCON,#01010000B ; Serial Mode1
	MOV 	TH1,#0FBH 	; 9600 FBH@18.432MHz
	SETB 	TR1 		; Start Timer1

Main_Loop: 
	MOV 	A,#'A'
	MOV 	SBUF,A
	JNB 	TI,$
	CLR 	TI
	CALL 	Delay
	JMP 	Main_Loop
	
Delay: 	CLR 	A
	MOV 	B,A
	
Dly00: 	DJNZ 	Acc,Dly00
	DJNZ 	B,Dly00
	RET
	END